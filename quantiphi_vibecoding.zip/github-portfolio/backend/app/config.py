"""Central configuration loaded from environment variables (.env supported)."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]  # project root
load_dotenv(BASE_DIR / ".env")
load_dotenv(BASE_DIR / "backend" / ".env")

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "").strip()
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "3600"))
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "backend" / "cache.db"))
FRONTEND_DIR = BASE_DIR / "frontend"

# Optional LLM (chatbot works without it via rule-based engine)
LLM_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
LLM_MODEL = os.getenv("LLM_MODEL", "claude-haiku-4-5")

GITHUB_GRAPHQL_URL = "https://api.github.com/graphql"
GITHUB_REST_URL = "https://api.github.com"
