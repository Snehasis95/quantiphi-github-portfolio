"""SQLite connection + schema. One connection per call keeps it thread-safe for FastAPI."""
import sqlite3
from contextlib import contextmanager

from .config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    username      TEXT PRIMARY KEY,
    name          TEXT,
    avatar_url    TEXT,
    bio           TEXT,
    html_url      TEXT,
    followers     INTEGER DEFAULT 0,
    following     INTEGER DEFAULT 0,
    public_repos  INTEGER DEFAULT 0,
    fetched_at    REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS repos (
    username       TEXT NOT NULL,
    name           TEXT NOT NULL,
    description    TEXT,
    url            TEXT,
    stars          INTEGER DEFAULT 0,
    forks          INTEGER DEFAULT 0,
    language       TEXT,
    language_color TEXT,
    is_fork        INTEGER DEFAULT 0,
    updated_at     TEXT,
    PRIMARY KEY (username, name)
);

CREATE TABLE IF NOT EXISTS repo_languages (
    username  TEXT NOT NULL,
    repo      TEXT NOT NULL,
    language  TEXT NOT NULL,
    bytes     INTEGER DEFAULT 0,
    PRIMARY KEY (username, repo, language)
);

CREATE TABLE IF NOT EXISTS contributions (
    username  TEXT NOT NULL,
    date      TEXT NOT NULL,
    count     INTEGER DEFAULT 0,
    PRIMARY KEY (username, date)
);

CREATE TABLE IF NOT EXISTS settings (
    key    TEXT PRIMARY KEY,
    value  TEXT
);

CREATE INDEX IF NOT EXISTS idx_repos_user ON repos(username);
CREATE INDEX IF NOT EXISTS idx_contrib_user ON contributions(username);
"""


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with get_conn() as conn:
        conn.executescript(SCHEMA)
