"""FastAPI entry point. Run from the backend/ folder:  uvicorn app.main:app --reload"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .config import FRONTEND_DIR, GITHUB_TOKEN
from .db import init_db
from .routes import assistant, contributions, match, profile, repos


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    yield


app = FastAPI(title="GitHub Developer Portfolio API", version="1.0.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

for r in (profile.router, repos.router, contributions.router, match.router, assistant.router):
    app.include_router(r)


@app.get("/api/health")
def health():
    return {"status": "ok", "github_auth": "token" if GITHUB_TOKEN else "anonymous (REST fallback)"}


# Serve the frontend last so /api/* routes take priority.
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
