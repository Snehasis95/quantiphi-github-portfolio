"""Shared validation + error mapping for routes."""
import re

from fastapi import HTTPException

from ..services.cache import get_bundle, get_cached_bundle
from ..services.github_client import GitHubError

USERNAME_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?$")


def validate_username(username: str) -> str:
    username = (username or "").strip()
    if not USERNAME_RE.match(username):
        raise HTTPException(status_code=400, detail="Invalid GitHub username")
    return username


async def load_bundle(username: str, refresh: bool = False) -> dict:
    username = validate_username(username)
    try:
        return await get_bundle(username, refresh=refresh)
    except GitHubError as e:
        raise HTTPException(status_code=e.status, detail=str(e))


async def load_cached_or_fetch(username: str) -> dict:
    """Match/chat prefer the cache; only fetch if the user was never loaded."""
    username = validate_username(username)
    return get_cached_bundle(username) or await load_bundle(username)
