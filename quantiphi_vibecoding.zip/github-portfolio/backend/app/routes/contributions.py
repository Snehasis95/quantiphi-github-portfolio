from fastapi import APIRouter

from ..services import stats
from .deps import load_bundle

router = APIRouter(prefix="/api", tags=["contributions"])


@router.get("/contributions/{username}")
async def get_contributions(username: str):
    b = await load_bundle(username)
    return stats.contribution_heatmap(b["contributions"])
