from typing import Literal

from fastapi import APIRouter, Query

from ..services import stats
from .deps import load_bundle

router = APIRouter(prefix="/api", tags=["repos"])


@router.get("/repos/{username}")
async def get_repos(
    username: str,
    sort: Literal["stars", "updated", "forks", "name"] = "stars",
    include_forks: bool = False,
    limit: int = Query(30, ge=1, le=100),
):
    b = await load_bundle(username)
    items = stats.sort_repos(b["repos"], sort, include_forks)[:limit]
    return {
        "count": len(items),
        "repos": [{k: r[k] for k in ("name", "description", "url", "stars", "forks",
                                     "language", "language_color", "is_fork", "updated_at")}
                  for r in items],
    }
