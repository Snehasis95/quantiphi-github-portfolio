import time

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..services import stats
from ..services.cache import get_setting, set_setting
from ..services.matcher import compute_match
from .deps import load_cached_or_fetch, validate_username

router = APIRouter(prefix="/api", tags=["match"])


class MatchRequest(BaseModel):
    username: str
    job_description: str = Field(..., min_length=1, max_length=20000)


def user_language_percents(bundle: dict) -> dict[str, float]:
    breakdown = stats.language_breakdown(bundle["languages"], bundle["repos"], top_n=100)
    percents = {l["language"]: l["percent"] for l in breakdown}
    for lang in stats.language_set(bundle["languages"], bundle["repos"]):
        percents.setdefault(lang, 0.0)  # repos whose language has no byte data still count
    return percents


def run_match(bundle: dict, jd: str) -> dict:
    try:
        return compute_match(jd, user_language_percents(bundle))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/match")
async def match(req: MatchRequest):
    bundle = await load_cached_or_fetch(req.username)
    result = run_match(bundle, req.job_description)
    # persist last result as a user setting so the badge survives page reloads
    set_setting(f"last_match:{req.username.lower()}", {**result, "computed_at": time.time()})
    return result


@router.get("/match/{username}")
async def last_match(username: str):
    username = validate_username(username)
    return get_setting(f"last_match:{username.lower()}") or {}
