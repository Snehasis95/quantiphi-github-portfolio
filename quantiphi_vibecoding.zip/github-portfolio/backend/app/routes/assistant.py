from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ..services import assistant
from .deps import load_cached_or_fetch
from .match import run_match

router = APIRouter(prefix="/api", tags=["assistant"])


class ChatRequest(BaseModel):
    username: str
    message: str = Field(..., min_length=1, max_length=500)


class InsightsRequest(BaseModel):
    username: str
    job_description: str = Field(..., min_length=1, max_length=20000)


@router.post("/chat")
async def chat(req: ChatRequest):
    bundle = await load_cached_or_fetch(req.username)
    try:
        return await assistant.answer(req.message, bundle)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/insights")
async def insights(req: InsightsRequest):
    bundle = await load_cached_or_fetch(req.username)
    match = run_match(bundle, req.job_description)
    return {"match": match, **assistant.career_insights(match, bundle)}
