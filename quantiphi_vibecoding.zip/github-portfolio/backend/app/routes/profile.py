from fastapi import APIRouter, Query

from ..services import stats
from .deps import load_bundle

router = APIRouter(prefix="/api", tags=["profile"])


@router.get("/profile/{username}")
async def get_profile(username: str, refresh: bool = Query(False)):
    b = await load_bundle(username, refresh)
    p = b["profile"]
    return {
        "username": p["username"],
        "name": p["name"],
        "avatar_url": p["avatar_url"],
        "bio": p["bio"],
        "html_url": p["html_url"],
        "followers": p["followers"],
        "following": p["following"],
        "public_repos": p["public_repos"],
        "total_stars": stats.total_stars(b["repos"]),
        "total_forks": stats.total_forks(b["repos"]),
        "top_languages": stats.language_breakdown(b["languages"], b["repos"]),
        "cache": b["cache"],
    }
