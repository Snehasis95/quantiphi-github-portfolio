"""Tech Stack Compatibility engine.

1. Extract required skills from the job description using a canonical skill dictionary with aliases
   (word-boundary regex, so 'go' doesn't match 'good'; 'C', 'R', 'Go' matched case-sensitively).
2. Frameworks map to the language they imply (React -> JavaScript, Django -> Python ...).
3. Compare with languages present in the user's cached repos.
4. Match % = matched / required * 100, plus a usage-weighted "depth" score as extra info.
"""
import re

# canonical language name (as GitHub reports it) -> lowercase aliases
LANGUAGE_ALIASES: dict[str, list[str]] = {
    "Python": ["python", "py", "python3"],
    "JavaScript": ["javascript", "js", "ecmascript", "es6"],
    "TypeScript": ["typescript", "ts"],
    "Java": ["java"],
    "C++": ["c++", "cpp", "cplusplus"],
    "C#": ["c#", "csharp", ".net", "dotnet"],
    "Go": ["golang"],
    "Rust": ["rust"],
    "Ruby": ["ruby"],
    "PHP": ["php"],
    "Swift": ["swift"],
    "Kotlin": ["kotlin"],
    "Scala": ["scala"],
    "Dart": ["dart"],
    "HTML": ["html", "html5"],
    "CSS": ["css", "css3", "scss", "sass", "tailwind"],
    "Shell": ["shell", "bash", "shell scripting", "zsh"],
    "Jupyter Notebook": ["jupyter"],
    "Cuda": ["cuda"],
    "SQL": ["sql", "plsql", "t-sql", "postgresql", "mysql", "sqlite"],
    "Solidity": ["solidity"],
    "Haskell": ["haskell"],
    "Lua": ["lua"],
    "Perl": ["perl"],
    "MATLAB": ["matlab"],
    "Dockerfile": ["docker", "dockerfile"],
    "HCL": ["terraform", "hcl"],
}

# Single-letter / ambiguous names: case-sensitive, standalone only.
CASE_SENSITIVE = {"C": r"(?<![\w+#])C(?![\w+#])", "R": r"(?<![\w])R(?![\w])", "Go": r"(?<![\w])Go(?![\w-])"}

# Frameworks/tools imply a language requirement.
FRAMEWORK_TO_LANGUAGE: dict[str, str] = {
    "react": "JavaScript", "reactjs": "JavaScript", "node": "JavaScript", "nodejs": "JavaScript",
    "node.js": "JavaScript", "express": "JavaScript", "vue": "JavaScript", "angular": "TypeScript",
    "next.js": "JavaScript", "nextjs": "JavaScript",
    "django": "Python", "flask": "Python", "fastapi": "Python", "pandas": "Python", "numpy": "Python",
    "pytorch": "Python", "tensorflow": "Python", "scikit-learn": "Python",
    "spring": "Java", "spring boot": "Java", "hibernate": "Java",
    "rails": "Ruby", "laravel": "PHP", "flutter": "Dart", "android": "Kotlin", "ios": "Swift",
    "asp.net": "C#", "unity": "C#", "stl": "C++", "boost": "C++",
}

# Languages treated as equivalent evidence (a TS dev can do JS, etc.)
EQUIVALENTS = {"JavaScript": {"TypeScript"}, "TypeScript": {"JavaScript"}, "SQL": {"PLpgSQL", "TSQL"},
               "Python": {"Jupyter Notebook"}, "Jupyter Notebook": {"Python"}, "C": {"C++"}}

MAX_JD_CHARS = 20000


def _pattern(alias: str) -> re.Pattern:
    return re.compile(r"(?<![a-z0-9+#.])" + re.escape(alias) + r"(?![a-z0-9+#])")


_COMPILED = {lang: [_pattern(a) for a in aliases] for lang, aliases in LANGUAGE_ALIASES.items()}
_FRAMEWORKS = {fw: _pattern(fw) for fw in FRAMEWORK_TO_LANGUAGE}
_CS = {lang: re.compile(p) for lang, p in CASE_SENSITIVE.items()}


def extract_skills(job_description: str) -> dict[str, list[str]]:
    """Returns {language: [evidence keywords found in JD]}."""
    text = job_description.lower()
    found: dict[str, list[str]] = {}
    for lang, patterns in _COMPILED.items():
        hits = [LANGUAGE_ALIASES[lang][i] for i, p in enumerate(patterns) if p.search(text)]
        if hits:
            found.setdefault(lang, []).extend(hits)
    for lang, p in _CS.items():
        if p.search(job_description):
            found.setdefault(lang, []).append(lang)
    for fw, p in _FRAMEWORKS.items():
        if p.search(text):
            found.setdefault(FRAMEWORK_TO_LANGUAGE[fw], []).append(fw)
    return {k: sorted(set(v)) for k, v in found.items()}


def compute_match(job_description: str, user_languages: dict[str, float]) -> dict:
    """user_languages: {language: percent_of_code}. Pure function -> easy to unit test."""
    jd = (job_description or "").strip()
    if not jd:
        raise ValueError("Job description is empty")
    if len(jd) > MAX_JD_CHARS:
        raise ValueError(f"Job description too long (max {MAX_JD_CHARS} chars)")

    required = extract_skills(jd)
    user_lower = {l.lower(): l for l in user_languages}

    matched, missing = [], []
    for lang, evidence in sorted(required.items()):
        candidates = {lang} | EQUIVALENTS.get(lang, set())
        owned = next((user_lower[c.lower()] for c in candidates if c.lower() in user_lower), None)
        entry = {"skill": lang, "jd_keywords": evidence}
        if owned:
            entry["via"] = owned
            entry["usage_percent"] = round(user_languages.get(owned, 0), 1)
            matched.append(entry)
        else:
            missing.append(entry)

    total = len(required)
    percent = round(len(matched) * 100 / total) if total else 0
    # depth: how much of the user's code is in the matched languages (0-100)
    depth = round(min(100, sum(m["usage_percent"] for m in matched)), 1)

    if total == 0:
        label, color = "No tech keywords found", "gray"
    elif percent >= 70:
        label, color = "Strong Match", "green"
    elif percent >= 40:
        label, color = "Partial Match", "amber"
    else:
        label, color = "Low Match", "red"

    return {
        "match_percent": percent,
        "depth_percent": depth,
        "label": label,
        "badge_color": color,
        "required_count": total,
        "matched": matched,
        "missing": missing,
    }
