"""GitHub API client.

With a token  -> single GraphQL query (profile + repos + languages + contribution calendar).
Without token -> REST fallback (contributions approximated from public events, last ~90 days).
Returns one normalized dict so the rest of the app never cares which API was used.
"""
from collections import Counter

import httpx

from ..config import GITHUB_GRAPHQL_URL, GITHUB_REST_URL, GITHUB_TOKEN


class GitHubError(Exception):
    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.status = status


GRAPHQL_QUERY = """
query($login: String!) {
  user(login: $login) {
    login name avatarUrl bio url
    followers { totalCount }
    following { totalCount }
    repositories(first: 100, ownerAffiliations: OWNER, privacy: PUBLIC,
                 orderBy: {field: STARGAZERS, direction: DESC}) {
      totalCount
      nodes {
        name description url stargazerCount forkCount isFork updatedAt
        primaryLanguage { name color }
        languages(first: 10, orderBy: {field: SIZE, direction: DESC}) {
          edges { size node { name } }
        }
      }
    }
    contributionsCollection {
      contributionCalendar {
        totalContributions
        weeks { contributionDays { date contributionCount } }
      }
    }
  }
}
"""


def _headers() -> dict:
    h = {"Accept": "application/vnd.github+json", "User-Agent": "github-portfolio-app"}
    if GITHUB_TOKEN:
        h["Authorization"] = f"Bearer {GITHUB_TOKEN}"
    return h


def _check(resp: httpx.Response) -> None:
    if resp.status_code == 404:
        raise GitHubError("GitHub user not found", 404)
    if resp.status_code in (403, 429):
        raise GitHubError("GitHub API rate limit exceeded", 429)
    if resp.status_code == 401:
        raise GitHubError("Invalid GitHub token", 401)
    if resp.status_code >= 400:
        raise GitHubError(f"GitHub API error ({resp.status_code})", 502)


async def fetch_user_bundle(username: str) -> dict:
    if GITHUB_TOKEN:
        return await _fetch_graphql(username)
    return await _fetch_rest(username)


async def _fetch_graphql(username: str) -> dict:
    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.post(
            GITHUB_GRAPHQL_URL,
            json={"query": GRAPHQL_QUERY, "variables": {"login": username}},
            headers=_headers(),
        )
    _check(resp)
    payload = resp.json()
    user = (payload.get("data") or {}).get("user")
    if not user:
        errors = payload.get("errors") or []
        if any(e.get("type") == "NOT_FOUND" for e in errors) or not errors:
            raise GitHubError("GitHub user not found", 404)
        raise GitHubError(errors[0].get("message", "GraphQL error"), 502)

    repos, languages = [], []
    for r in user["repositories"]["nodes"]:
        pl = r.get("primaryLanguage") or {}
        repos.append({
            "name": r["name"],
            "description": r.get("description") or "",
            "url": r["url"],
            "stars": r["stargazerCount"],
            "forks": r["forkCount"],
            "language": pl.get("name"),
            "language_color": pl.get("color"),
            "is_fork": bool(r["isFork"]),
            "updated_at": r["updatedAt"],
        })
        for edge in r["languages"]["edges"]:
            languages.append({"repo": r["name"], "language": edge["node"]["name"], "bytes": edge["size"]})

    contributions = [
        {"date": d["date"], "count": d["contributionCount"]}
        for w in user["contributionsCollection"]["contributionCalendar"]["weeks"]
        for d in w["contributionDays"]
    ]
    return {
        "profile": {
            "username": user["login"],
            "name": user.get("name") or user["login"],
            "avatar_url": user["avatarUrl"],
            "bio": user.get("bio") or "",
            "html_url": user["url"],
            "followers": user["followers"]["totalCount"],
            "following": user["following"]["totalCount"],
            "public_repos": user["repositories"]["totalCount"],
        },
        "repos": repos,
        "languages": languages,
        "contributions": contributions,
    }


async def _fetch_rest(username: str) -> dict:
    async with httpx.AsyncClient(timeout=20, headers=_headers()) as client:
        u = await client.get(f"{GITHUB_REST_URL}/users/{username}")
        _check(u)
        user = u.json()
        r = await client.get(f"{GITHUB_REST_URL}/users/{username}/repos",
                             params={"per_page": 100, "sort": "updated"})
        _check(r)
        raw_repos = r.json()
        ev = await client.get(f"{GITHUB_REST_URL}/users/{username}/events/public",
                              params={"per_page": 100})
        events = ev.json() if ev.status_code == 200 else []

    repos, languages = [], []
    for rp in raw_repos:
        repos.append({
            "name": rp["name"],
            "description": rp.get("description") or "",
            "url": rp["html_url"],
            "stars": rp["stargazers_count"],
            "forks": rp["forks_count"],
            "language": rp.get("language"),
            "language_color": None,
            "is_fork": bool(rp["fork"]),
            "updated_at": rp["updated_at"],
        })
        # Without a token we avoid N extra calls; approximate bytes with repo size.
        if rp.get("language"):
            languages.append({"repo": rp["name"], "language": rp["language"],
                              "bytes": max(rp.get("size", 1), 1) * 1024})

    per_day = Counter(e["created_at"][:10] for e in events if e.get("created_at"))
    contributions = [{"date": d, "count": c} for d, c in sorted(per_day.items())]

    return {
        "profile": {
            "username": user["login"],
            "name": user.get("name") or user["login"],
            "avatar_url": user["avatar_url"],
            "bio": user.get("bio") or "",
            "html_url": user["html_url"],
            "followers": user["followers"],
            "following": user["following"],
            "public_repos": user["public_repos"],
        },
        "repos": repos,
        "languages": languages,
        "contributions": contributions,
    }
