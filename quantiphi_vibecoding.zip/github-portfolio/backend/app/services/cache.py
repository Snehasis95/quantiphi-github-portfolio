"""SQLite caching layer (read-through cache with TTL).

get_bundle():
  1. If cached data for the user is younger than CACHE_TTL_SECONDS -> serve from SQLite.
  2. Otherwise fetch from GitHub, upsert into SQLite, serve.
  3. If GitHub fails (e.g. rate limited) but stale data exists -> serve stale data (flagged).
"""
import json
import time

from ..config import CACHE_TTL_SECONDS
from ..db import get_conn
from .github_client import GitHubError, fetch_user_bundle


def _is_fresh(fetched_at: float) -> bool:
    return (time.time() - fetched_at) < CACHE_TTL_SECONDS


def _save_bundle(bundle: dict) -> None:
    p = bundle["profile"]
    key = p["username"].lower()
    with get_conn() as conn:
        conn.execute(
            """INSERT OR REPLACE INTO users
               (username, name, avatar_url, bio, html_url, followers, following, public_repos, fetched_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (key, p["name"], p["avatar_url"], p["bio"], p["html_url"],
             p["followers"], p["following"], p["public_repos"], time.time()),
        )
        # Replace child rows atomically so deleted repos disappear from cache.
        conn.execute("DELETE FROM repos WHERE username=?", (key,))
        conn.execute("DELETE FROM repo_languages WHERE username=?", (key,))
        conn.execute("DELETE FROM contributions WHERE username=?", (key,))
        conn.executemany(
            """INSERT INTO repos (username, name, description, url, stars, forks,
               language, language_color, is_fork, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)""",
            [(key, r["name"], r["description"], r["url"], r["stars"], r["forks"],
              r["language"], r["language_color"], int(r["is_fork"]), r["updated_at"])
             for r in bundle["repos"]],
        )
        conn.executemany(
            "INSERT OR REPLACE INTO repo_languages (username, repo, language, bytes) VALUES (?,?,?,?)",
            [(key, l["repo"], l["language"], l["bytes"]) for l in bundle["languages"]],
        )
        conn.executemany(
            "INSERT OR REPLACE INTO contributions (username, date, count) VALUES (?,?,?)",
            [(key, c["date"], c["count"]) for c in bundle["contributions"]],
        )


def _load_bundle(username: str) -> dict | None:
    key = username.lower()
    with get_conn() as conn:
        user = conn.execute("SELECT * FROM users WHERE username=?", (key,)).fetchone()
        if not user:
            return None
        repos = [dict(r) for r in conn.execute(
            "SELECT * FROM repos WHERE username=? ORDER BY stars DESC", (key,))]
        langs = [dict(r) for r in conn.execute(
            "SELECT repo, language, bytes FROM repo_languages WHERE username=?", (key,))]
        contribs = [dict(r) for r in conn.execute(
            "SELECT date, count FROM contributions WHERE username=? ORDER BY date", (key,))]
    for r in repos:
        r["is_fork"] = bool(r["is_fork"])
    return {"profile": dict(user), "repos": repos, "languages": langs, "contributions": contribs}


async def get_bundle(username: str, refresh: bool = False) -> dict:
    cached = _load_bundle(username)
    if cached and not refresh and _is_fresh(cached["profile"]["fetched_at"]):
        cached["cache"] = {"hit": True, "stale": False, "fetched_at": cached["profile"]["fetched_at"]}
        return cached
    try:
        fresh = await fetch_user_bundle(username)
    except GitHubError:
        if cached:  # graceful degradation: stale data beats an error page
            cached["cache"] = {"hit": True, "stale": True, "fetched_at": cached["profile"]["fetched_at"]}
            return cached
        raise
    _save_bundle(fresh)
    loaded = _load_bundle(username)
    loaded["cache"] = {"hit": False, "stale": False, "fetched_at": loaded["profile"]["fetched_at"]}
    return loaded


def get_cached_bundle(username: str) -> dict | None:
    """Cache-only read (used by match/chat so they never hit the GitHub API)."""
    return _load_bundle(username)


# ---- user settings (key/value) ----
def set_setting(key: str, value) -> None:
    with get_conn() as conn:
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, json.dumps(value)))


def get_setting(key: str, default=None):
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return json.loads(row["value"]) if row else default
