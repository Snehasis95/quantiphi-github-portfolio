"""All derived metrics are computed here (server-side), never in the browser."""
from collections import defaultdict
from datetime import date, timedelta

# Fallback colors for the pie chart when GitHub doesn't give one.
PALETTE = ["#3b82f6", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6", "#64748b"]


def total_stars(repos: list[dict]) -> int:
    return sum(r["stars"] for r in repos if not r["is_fork"])


def total_forks(repos: list[dict]) -> int:
    return sum(r["forks"] for r in repos if not r["is_fork"])


def language_breakdown(languages: list[dict], repos: list[dict], top_n: int = 5) -> list[dict]:
    """Percent of code per language, weighted by bytes; languages beyond top_n grouped as 'Other'."""
    fork_names = {r["name"] for r in repos if r["is_fork"]}
    color_of = {r["language"]: r["language_color"] for r in repos if r.get("language_color")}
    totals: dict[str, int] = defaultdict(int)
    for l in languages:
        if l["repo"] not in fork_names:
            totals[l["language"]] += l["bytes"]
    grand = sum(totals.values())
    if grand == 0:
        return []
    ranked = sorted(totals.items(), key=lambda kv: kv[1], reverse=True)
    top, rest = ranked[:top_n], ranked[top_n:]
    out = []
    for i, (lang, b) in enumerate(top):
        out.append({"language": lang, "bytes": b, "percent": round(b * 100 / grand, 1),
                    "color": color_of.get(lang) or PALETTE[i % len(PALETTE)]})
    if rest:
        b = sum(v for _, v in rest)
        out.append({"language": "Other", "bytes": b, "percent": round(b * 100 / grand, 1),
                    "color": PALETTE[-1]})
    return out


def language_set(languages: list[dict], repos: list[dict]) -> set[str]:
    forks = {r["name"] for r in repos if r["is_fork"]}
    langs = {l["language"] for l in languages if l["repo"] not in forks}
    langs |= {r["language"] for r in repos if r.get("language") and not r["is_fork"]}
    return langs


def _intensity_thresholds(counts: list[int]) -> list[int]:
    """Quartiles of non-zero days -> 4 thresholds for levels 1..4 (like GitHub)."""
    nz = sorted(c for c in counts if c > 0)
    if not nz:
        return [1, 1, 1, 1]
    q = lambda p: nz[min(len(nz) - 1, int(p * len(nz)))]
    return [1, q(0.25), q(0.5), q(0.75)]


def _level(count: int, th: list[int]) -> int:
    if count <= 0:
        return 0
    if count >= th[3]:
        return 4
    if count >= th[2]:
        return 3
    if count >= th[1]:
        return 2
    return 1


def contribution_heatmap(contributions: list[dict], days: int = 365) -> dict:
    """Builds a dense last-`days` calendar (gaps filled with 0) with intensity levels + streaks."""
    by_date = {c["date"]: c["count"] for c in contributions}
    today = date.today()
    start = today - timedelta(days=days - 1)
    start -= timedelta(days=(start.weekday() + 1) % 7)  # align to Sunday like GitHub

    cells, d = [], start
    while d <= today:
        cells.append({"date": d.isoformat(), "count": by_date.get(d.isoformat(), 0)})
        d += timedelta(days=1)

    th = _intensity_thresholds([c["count"] for c in cells])
    for c in cells:
        c["level"] = _level(c["count"], th)

    weeks = [cells[i:i + 7] for i in range(0, len(cells), 7)]
    return {
        "weeks": weeks,
        "total": sum(c["count"] for c in cells),
        "active_days": sum(1 for c in cells if c["count"] > 0),
        "thresholds": th,
        **streaks(cells, today),
    }


def streaks(cells: list[dict], today: date) -> dict:
    longest = run = 0
    for c in cells:
        run = run + 1 if c["count"] > 0 else 0
        longest = max(longest, run)

    by_date = {c["date"]: c["count"] for c in cells}
    current = 0
    d = today
    if by_date.get(d.isoformat(), 0) == 0:  # today not coded yet -> streak can still be alive
        d -= timedelta(days=1)
    while by_date.get(d.isoformat(), 0) > 0:
        current += 1
        d -= timedelta(days=1)
    return {"current_streak": current, "longest_streak": longest}


def sort_repos(repos: list[dict], sort: str = "stars", include_forks: bool = False) -> list[dict]:
    items = [r for r in repos if include_forks or not r["is_fork"]]
    if sort == "updated":
        return sorted(items, key=lambda r: r["updated_at"] or "", reverse=True)
    if sort == "forks":
        return sorted(items, key=lambda r: r["forks"], reverse=True)
    if sort == "name":
        return sorted(items, key=lambda r: r["name"].lower())
    return sorted(items, key=lambda r: (r["stars"], r["forks"]), reverse=True)
