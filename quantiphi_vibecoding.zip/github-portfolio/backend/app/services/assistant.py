"""Extra features (chatbot capabilities):

1. Portfolio chatbot  - answers recruiter questions about the developer from the SQLite cache.
   Rule-based intent engine (works offline); optionally upgraded by an LLM if ANTHROPIC_API_KEY is set.
2. Career insights     - skill-gap advisor built on the JD match result: strengths, gaps,
   repos to pin, and project ideas to close the gaps.
"""
import json
import re

import httpx

from ..config import LLM_API_KEY, LLM_MODEL
from . import stats

MAX_MSG_CHARS = 500

PROJECT_IDEAS = {
    "Python": "a FastAPI REST service with tests and a SQLite/Postgres backend",
    "JavaScript": "an interactive single-page app (React/Vanilla) consuming a public API",
    "TypeScript": "a typed Node/Express API or React app with strict mode enabled",
    "Java": "a Spring Boot microservice with JPA and unit tests",
    "C++": "a performance-focused tool (e.g. a thread pool or LRU cache) with benchmarks",
    "C#": "an ASP.NET Core Web API with Entity Framework",
    "Go": "a concurrent CLI or HTTP service using goroutines and channels",
    "Rust": "a CLI tool using clap + serde with cargo tests",
    "SQL": "a data-modeling project with schema design, indexes and analytical queries",
    "Kotlin": "a small Android app with Jetpack Compose",
    "Swift": "a SwiftUI iOS app",
    "Dockerfile": "containerize an existing project with a multi-stage Dockerfile + compose",
    "HCL": "Terraform scripts to provision a small cloud stack",
}


def build_context(bundle: dict) -> dict:
    """Compact, server-computed facts about the developer (used by both rule engine and LLM)."""
    repos = [r for r in bundle["repos"] if not r["is_fork"]]
    heat = stats.contribution_heatmap(bundle["contributions"])
    langs = stats.language_breakdown(bundle["languages"], bundle["repos"], top_n=8)
    p = bundle["profile"]
    return {
        "name": p["name"], "username": p["username"], "bio": p["bio"],
        "followers": p["followers"], "public_repos": p["public_repos"],
        "total_stars": stats.total_stars(bundle["repos"]),
        "languages": langs,
        "current_streak": heat["current_streak"], "longest_streak": heat["longest_streak"],
        "contributions_last_year": heat["total"], "active_days": heat["active_days"],
        "repos": [{"name": r["name"], "stars": r["stars"], "forks": r["forks"], "language": r["language"],
                   "description": r["description"], "updated_at": r["updated_at"]} for r in repos],
    }


def _fmt_repo(r: dict) -> str:
    desc = f" — {r['description']}" if r["description"] else ""
    return f"**{r['name']}** ({r['language'] or 'n/a'}, ★{r['stars']}){desc}"


def rule_based_answer(message: str, ctx: dict) -> str:
    q = message.lower()
    repos = ctx["repos"]
    name = ctx["name"]

    # language-specific question: "which repos use python?"
    for lang in sorted({r["language"] for r in repos if r["language"]}, key=len, reverse=True):
        if re.search(r"(?<![a-z0-9+#])" + re.escape(lang.lower()) + r"(?![a-z0-9+#])", q):
            hits = [r for r in repos if (r["language"] or "").lower() == lang.lower()]
            lines = "\n".join(f"- {_fmt_repo(r)}" for r in hits[:5])
            return f"{name} has {len(hits)} repo(s) primarily in {lang}:\n{lines}"

    if any(k in q for k in ["best", "top", "most star", "popular", "famous", "flagship"]):
        top = sorted(repos, key=lambda r: r["stars"], reverse=True)[:3]
        if not top:
            return f"{name} has no public repositories yet."
        return "Top projects by stars:\n" + "\n".join(f"- {_fmt_repo(r)}" for r in top)

    if any(k in q for k in ["recent", "latest", "working on", "currently", "new"]):
        rec = sorted(repos, key=lambda r: r["updated_at"] or "", reverse=True)[:3]
        return "Most recently updated:\n" + "\n".join(f"- {_fmt_repo(r)}" for r in rec)

    if any(k in q for k in ["streak", "active", "consistent", "contribution", "commit", "how often"]):
        return (f"{name} made {ctx['contributions_last_year']} contributions over the last year across "
                f"{ctx['active_days']} active days. Current streak: {ctx['current_streak']} day(s); "
                f"longest streak: {ctx['longest_streak']} day(s).")

    if any(k in q for k in ["language", "stack", "skill", "tech", "know"]):
        langs = ", ".join(f"{l['language']} ({l['percent']}%)" for l in ctx["languages"]) or "no data"
        return f"{name}'s code by language: {langs}."

    if "star" in q:
        return f"{name} has earned {ctx['total_stars']} stars across {len(repos)} original repositories."

    if any(k in q for k in ["follower", "popular", "audience"]):
        return f"{name} has {ctx['followers']} followers on GitHub."

    if any(k in q for k in ["who", "about", "summary", "introduce", "tell me", "overview", "hire"]):
        top_lang = ctx["languages"][0]["language"] if ctx["languages"] else "various languages"
        best = max(repos, key=lambda r: r["stars"], default=None)
        best_txt = f" Their flagship project is {_fmt_repo(best)}." if best else ""
        bio = f" Bio: “{ctx['bio']}”." if ctx["bio"] else ""
        return (f"{name} (@{ctx['username']}) mainly codes in {top_lang}, has {len(repos)} public projects, "
                f"{ctx['total_stars']} stars and {ctx['followers']} followers.{bio}{best_txt}")

    return ("I can answer questions about this developer's projects, languages, stars, activity and streaks. "
            "Try: “What are the top projects?”, “Which repos use Python?”, or “How active are they?”")


async def _llm_answer(message: str, ctx: dict) -> str | None:
    if not LLM_API_KEY:
        return None
    prompt = (
        "You are a portfolio assistant answering a recruiter's question about a developer. "
        "Use ONLY the JSON facts below; if the answer is not there, say so. Be concise (<=120 words).\n\n"
        f"FACTS:\n{json.dumps(ctx)[:12000]}\n\nQUESTION: {message}"
    )
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": LLM_API_KEY, "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": LLM_MODEL, "max_tokens": 400,
                      "messages": [{"role": "user", "content": prompt}]},
            )
        if resp.status_code != 200:
            return None
        return "".join(b.get("text", "") for b in resp.json().get("content", [])) or None
    except httpx.HTTPError:
        return None


async def answer(message: str, bundle: dict) -> dict:
    msg = (message or "").strip()
    if not msg:
        raise ValueError("Message is empty")
    if len(msg) > MAX_MSG_CHARS:
        raise ValueError(f"Message too long (max {MAX_MSG_CHARS} chars)")
    ctx = build_context(bundle)
    llm = await _llm_answer(msg, ctx)
    if llm:
        return {"reply": llm, "engine": "llm"}
    return {"reply": rule_based_answer(msg, ctx), "engine": "rules"}


def career_insights(match: dict, bundle: dict) -> dict:
    repos = [r for r in bundle["repos"] if not r["is_fork"]]
    matched_langs = {m["via"] for m in match["matched"]}

    pin = sorted((r for r in repos if r["language"] in matched_langs),
                 key=lambda r: (r["stars"], r["forks"]), reverse=True)[:4]
    strengths = [f"{m['skill']} — {m['usage_percent']}% of your code" for m in
                 sorted(match["matched"], key=lambda m: m["usage_percent"], reverse=True)]
    gaps = [{"skill": m["skill"],
             "suggestion": f"Project idea: {PROJECT_IDEAS.get(m['skill'], 'a small project showcasing ' + m['skill'])}."}
            for m in match["missing"]]

    pct = match["match_percent"]
    if match["required_count"] == 0:
        verdict = "The job description didn't mention recognizable languages/frameworks."
    elif pct >= 70:
        verdict = "Your GitHub strongly supports this role — lead with the pinned repos below."
    elif pct >= 40:
        verdict = "Decent fit. Close 1–2 gaps with a focused project before applying."
    else:
        verdict = "Low overlap. Consider building projects in the missing stack first."

    return {
        "verdict": verdict,
        "strengths": strengths,
        "gaps": gaps,
        "repos_to_pin": [{"name": r["name"], "url": r["url"], "language": r["language"],
                          "stars": r["stars"]} for r in pin],
    }
