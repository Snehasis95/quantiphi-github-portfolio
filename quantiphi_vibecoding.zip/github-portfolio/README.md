# DevFolio — GitHub Developer Portfolio

A personal-branding dashboard that visualizes a developer's GitHub activity, repositories and languages, scores how well their stack matches a job description, and includes an AI portfolio assistant.

## Features
| Feature | Where it lives |
|---|---|
| Contribution heatmap (intensity levels 0–4, streaks) | `services/stats.py → contribution_heatmap()` |
| Repository cards (stars, forks, language, description; sort + fork filter) | `routes/repos.py`, `stats.sort_repos()` |
| Profile header (followers, total stars, Top Languages pie) | `routes/profile.py`, `stats.language_breakdown()` |
| GitHub GraphQL (with token) / REST fallback (without) | `services/github_client.py` |
| SQLite caching engine with TTL + stale fallback | `services/cache.py`, `db.py` |
| **Vibe Check:** Tech Stack Compatibility % badge | `services/matcher.py`, `routes/match.py` |
| **Extra 1:** Portfolio chatbot (rule-based, optional LLM) | `services/assistant.py → answer()` |
| **Extra 2:** AI career insights / skill-gap advisor | `services/assistant.py → career_insights()` |

## Architecture
```
Browser (HTML/CSS/JS + Chart.js)  ── presentation only
        │  JSON over /api/*
FastAPI routes  ── validation (username regex, JD/message length), HTTP errors
        │
Services  ── stats · matcher · assistant   (all business logic & computation)
        │
Cache (SQLite, TTL)  ──miss/expired──►  GitHub GraphQL / REST
```
All calculations — total stars, language percentages, heatmap intensity levels, streaks, sorting, match %, chatbot answers, insights — run **server-side**. The frontend only renders.

### Caching strategy
- Tables: `users`, `repos`, `repo_languages`, `contributions`, `settings`.
- Read-through: if `users.fetched_at` is newer than `CACHE_TTL_SECONDS` (default 1h), serve from SQLite; otherwise fetch from GitHub and upsert.
- `?refresh=true` forces a re-fetch. If GitHub fails (rate limit), stale cached data is served and flagged.
- Match, chat and insights read **only from the cache**, so they never spend API quota.
- The last match result is stored in `settings`, so the badge persists across reloads.

### Match algorithm
1. Extract skills from the job description using a dictionary of languages and their aliases (`cpp → C++`, `golang → Go`). Matching uses word boundaries, and single-letter names like `C`, `R`, `Go` are matched case-sensitively.
2. Frameworks imply languages (`React → JavaScript`, `Django → Python`, `Spring → Java`).
3. Equivalents give credit (TypeScript satisfies JavaScript, for example).
4. **Match % = matched skills / required skills × 100**. Badge: ≥70 green, ≥40 amber, otherwise red.
5. **Depth %** = share of the user's code written in the matched languages.

## Run locally
```bash
cp .env.example .env          # add GITHUB_TOKEN (classic PAT, read:user scope)
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://localhost:8000 (frontend). API docs: http://localhost:8000/docs

## API
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/profile/{username}?refresh=` | Profile, total stars, top languages, cache info |
| GET | `/api/repos/{username}?sort=stars\|updated\|forks\|name&include_forks=` | Repo cards |
| GET | `/api/contributions/{username}` | Heatmap weeks with levels, totals, streaks |
| POST | `/api/match` `{username, job_description}` | Compatibility score |
| GET | `/api/match/{username}` | Last saved match (badge) |
| POST | `/api/chat` `{username, message}` | Portfolio assistant |
| POST | `/api/insights` `{username, job_description}` | Strengths, gaps, repos to pin |

## Tech stack
FastAPI · SQLite · httpx · GitHub GraphQL/REST · Vanilla JS · Chart.js
