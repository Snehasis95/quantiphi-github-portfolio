// Presentation layer only: fetches computed data from the backend and renders it.
const API = "/api";
const $ = (id) => document.getElementById(id);
let currentUser = null;
let langChart = null;

const escapeHtml = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => Number(n || 0).toLocaleString();

async function api(path, options = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = Array.isArray(data.detail) ? data.detail.map((d) => d.msg).join(", ") : data.detail;
    throw new Error(detail || `Request failed (${res.status})`);
  }
  return data;
}

function setStatus(msg, isError = false) {
  $("status").textContent = msg;
  $("status").className = "status" + (isError ? " error" : "");
}

// ---------- Load everything ----------
async function loadUser(username, refresh = false) {
  username = username.trim();
  if (!username) return;
  setStatus("Loading…");
  $("empty").classList.add("hidden");
  $("app").classList.remove("hidden");
  try {
    // Profile first (populates the cache), then the rest in parallel from cache.
    const profile = await api(`/profile/${encodeURIComponent(username)}?refresh=${refresh}`);
    currentUser = profile.username;
    renderProfile(profile);
    const [contrib, lastMatch] = await Promise.all([
      api(`/contributions/${encodeURIComponent(currentUser)}`),
      api(`/match/${encodeURIComponent(currentUser)}`),
      loadRepos(),
    ]);
    renderHeatmap(contrib);
    renderBadge(lastMatch && lastMatch.match_percent !== undefined ? lastMatch : null);
    $("match-result").innerHTML = "";
    $("insights-result").innerHTML = "";
    $("chat-toggle").classList.remove("hidden");
    $("chat-log").innerHTML = "";
    addMsg("bot", `Hi! Ask me anything about ${profile.name}'s GitHub work.`);
    history.replaceState(null, "", `?user=${encodeURIComponent(currentUser)}`);
    setStatus("");
  } catch (e) {
    setStatus(e.message, true);
  }
}

// ---------- Profile header + pie ----------
function renderProfile(p) {
  $("avatar").src = p.avatar_url;
  $("name").textContent = p.name;
  $("login").textContent = "@" + p.username;
  $("login").href = p.html_url;
  $("bio").textContent = p.bio || "";
  $("followers").textContent = fmt(p.followers);
  $("stars").textContent = fmt(p.total_stars);
  $("repos-count").textContent = fmt(p.public_repos);
  const when = new Date(p.cache.fetched_at * 1000).toLocaleTimeString();
  $("cache-info").textContent = p.cache.stale
    ? `⚠ GitHub unavailable — showing cached data from ${when}`
    : p.cache.hit ? `⚡ Served from SQLite cache (fetched ${when})` : `Fetched live from GitHub at ${when}`;

  if (langChart) langChart.destroy();
  langChart = new Chart($("lang-chart"), {
    type: "pie",
    data: {
      labels: p.top_languages.map((l) => l.language),
      datasets: [{ data: p.top_languages.map((l) => l.percent), backgroundColor: p.top_languages.map((l) => l.color), borderColor: "#161b22" }],
    },
    options: {
      plugins: {
        legend: { position: "bottom", labels: { color: "#e6edf3", boxWidth: 10, font: { size: 11 } } },
        tooltip: { callbacks: { label: (c) => `${c.label}: ${c.parsed}%` } },
      },
    },
  });
}

// ---------- Heatmap ----------
function renderHeatmap(h) {
  $("streak").textContent = `${h.current_streak}d`;
  $("longest").textContent = `${h.longest_streak}d`;
  $("contrib-total").textContent = `${fmt(h.total)} contributions · ${h.active_days} active days in the last year`;
  $("heatmap").innerHTML = h.weeks
    .map((w) => `<div class="week">${w.map((d) =>
      `<span class="day l${d.level}" title="${d.count} contributions on ${d.date}"></span>`).join("")}</div>`)
    .join("");
  $("heatmap").parentElement.scrollLeft = 99999; // show most recent weeks first on small screens
}

// ---------- Repo cards ----------
async function loadRepos() {
  if (!currentUser) return;
  const sort = $("sort-select").value;
  const forks = $("forks-toggle").checked;
  const data = await api(`/repos/${encodeURIComponent(currentUser)}?sort=${sort}&include_forks=${forks}`);
  $("repo-grid").innerHTML = data.repos.length
    ? data.repos.map(repoCard).join("")
    : `<p class="muted">No public repositories.</p>`;
}

function repoCard(r) {
  const lang = r.language
    ? `<span class="tag"><span class="dot" style="background:${escapeHtml(r.language_color || "#8b949e")}"></span>${escapeHtml(r.language)}</span>`
    : "";
  return `<div class="repo">
    <a href="${escapeHtml(r.url)}" target="_blank" rel="noopener">${escapeHtml(r.name)}</a>
    <p>${escapeHtml(r.description || "No description provided.")}</p>
    <div class="meta">${lang}<span>★ ${fmt(r.stars)}</span><span>⑂ ${fmt(r.forks)}</span>${r.is_fork ? "<span>fork</span>" : ""}</div>
  </div>`;
}

// ---------- JD match ----------
function renderBadge(m) {
  const b = $("match-badge");
  if (!m) return b.classList.add("hidden");
  b.className = `badge ${m.badge_color}`;
  b.textContent = `${m.match_percent}% Match · ${m.label}`;
}

function renderMatch(m) {
  renderBadge(m);
  const pills = (arr, cls) =>
    arr.map((x) => `<span class="pill ${cls}" title="JD keywords: ${escapeHtml(x.jd_keywords.join(", "))}">${escapeHtml(x.skill)}${x.via && x.via !== x.skill ? ` (via ${escapeHtml(x.via)})` : ""}</span>`).join("") || "<span class='muted'>—</span>";
  $("match-result").innerHTML = `<div class="match-box">
    <div class="big-pct" style="color:var(--${m.badge_color === "amber" ? "amber" : m.badge_color === "gray" ? "muted" : m.badge_color})">${m.match_percent}%</div>
    <div>
      <div><b>${escapeHtml(m.label)}</b> — ${m.matched.length}/${m.required_count} required skills found in your repos
        · code depth ${m.depth_percent}%</div>
      <div style="margin-top:6px">✅ ${pills(m.matched, "ok")}</div>
      <div>❌ ${pills(m.missing, "no")}</div>
    </div></div>`;
}

async function withButton(btn, fn) {
  btn.disabled = true;
  try { await fn(); } catch (e) { setStatus(e.message, true); } finally { btn.disabled = false; }
}

$("match-btn").onclick = () => withButton($("match-btn"), async () => {
  if (!currentUser) return;
  setStatus("");
  const m = await api("/match", { method: "POST", body: JSON.stringify({ username: currentUser, job_description: $("jd-input").value }) });
  renderMatch(m);
});

$("insights-btn").onclick = () => withButton($("insights-btn"), async () => {
  if (!currentUser) return;
  setStatus("");
  const r = await api("/insights", { method: "POST", body: JSON.stringify({ username: currentUser, job_description: $("jd-input").value }) });
  renderMatch(r.match);
  const li = (arr) => arr.length ? `<ul>${arr.join("")}</ul>` : "<p class='muted'>—</p>";
  $("insights-result").innerHTML = `<div class="insights">
    <b>✨ ${escapeHtml(r.verdict)}</b>
    <h4>💪 Strengths</h4>${li(r.strengths.map((s) => `<li>${escapeHtml(s)}</li>`))}
    <h4>🎯 Skill gaps & what to build</h4>${li(r.gaps.map((g) => `<li><b>${escapeHtml(g.skill)}:</b> ${escapeHtml(g.suggestion)}</li>`))}
    <h4>📌 Repos to pin for this role</h4>${li(r.repos_to_pin.map((p) => `<li><a href="${escapeHtml(p.url)}" target="_blank" rel="noopener">${escapeHtml(p.name)}</a> · ${escapeHtml(p.language)} · ★${fmt(p.stars)}</li>`))}
  </div>`;
});

// ---------- Chatbot ----------
function addMsg(who, text) {
  const div = document.createElement("div");
  div.className = `msg ${who}`;
  // minimal markdown: **bold**, after escaping
  div.innerHTML = escapeHtml(text).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
  $("chat-log").appendChild(div);
  $("chat-log").scrollTop = $("chat-log").scrollHeight;
}

async function sendChat(message) {
  message = message.trim();
  if (!message || !currentUser) return;
  addMsg("user", message);
  $("chat-input").value = "";
  try {
    const r = await api("/chat", { method: "POST", body: JSON.stringify({ username: currentUser, message }) });
    addMsg("bot", r.reply);
  } catch (e) {
    addMsg("bot", "⚠ " + e.message);
  }
}

$("chat-form").onsubmit = (e) => { e.preventDefault(); sendChat($("chat-input").value); };
document.querySelectorAll(".chips button").forEach((b) => (b.onclick = () => sendChat(b.dataset.q)));
$("chat-toggle").onclick = () => { $("chat").classList.remove("hidden"); $("chat-toggle").classList.add("hidden"); };
$("chat-close").onclick = () => { $("chat").classList.add("hidden"); $("chat-toggle").classList.remove("hidden"); };

// ---------- Wiring ----------
$("search-form").onsubmit = (e) => { e.preventDefault(); loadUser($("username-input").value); };
$("refresh-btn").onclick = () => loadUser($("username-input").value || currentUser || "", true);
$("sort-select").onchange = () => loadRepos().catch((e) => setStatus(e.message, true));
$("forks-toggle").onchange = () => loadRepos().catch((e) => setStatus(e.message, true));

const initial = new URLSearchParams(location.search).get("user");
if (initial) { $("username-input").value = initial; loadUser(initial); }
